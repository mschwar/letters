PRD policy update for community education and youth funds.

Date: 2026-02-08
Source: Universal House of Justice

This committee planning memo outlines policy and governance requirements for community building, youth training, education curriculum, and fund contribution strategy.
