THE UNIVERSAL HOUSE OF JUSTICE
April 2002
To The World’s Religious Leaders
The enduring legacy of the twentieth century is that it compelled the peoples of the world to
begin seeing themselves as the members of a single human race, and the earth as that race’s
common homeland. Despite the continuing conﬂict and violence that darken the horizon,
prejudices that once seemed inherent in the nature of the human species are everywhere giving
way. Down with them come barriers that long divided the family of man into a Babel of
incoherent identities of cultural, ethnic or national origin. That so fundamental a change could
occur in so brief a period—virtually overnight in the perspective of historical time—suggests the
magnitude of the possibilities for the future.
Tragically, organized religion, whose very reason for being entails service to the cause of
brotherhood and peace, behaves all too frequently as one of the most formidable obstacles in the
path; to cite a particular painful fact, it has long lent its credibility to fanaticism. We feel a
responsibility, as the governing council of one of the world religions, to urge earnest consideration
of the challenge this poses for religious leadership. Both the issue and the circumstances to which
it gives rise require that we speak frankly. We trust that common service to the Divine will ensure
that what we say will be received in the same spirit of goodwill as it is put forward.
The issue comes sharply into focus when one considers what has been achieved elsewhere. In
the past, apart from isolated exceptions, women were regarded as an inferior breed, their nature
hedged about by superstitions, denied the opportunity to express the potentialities of the human
spirit and relegated to the role of serving the needs of men. Clearly, there are many societies
where such conditions persist and are even fanatically defended. At the level of global discourse,
however, the concept of the equality of the sexes has, for all practical purposes, now assumed the
force of universally accepted principle. It enjoys similar authority in most of the academic
community and information media. So basic has been the revisioning that exponents of male
supremacy must look for support on the margins of responsible opinion.
The beleaguered battalions of nationalism face a similar fate. With each passing crisis in
world affairs, it becomes easier for the citizen to distinguish between a love of country that
enriches one’s life, and submission to inﬂammatory rhetoric designed to provoke hatred and fear
of others. Even where it is expedient to participate in the familiar nationalistic rites, public
response is as often marked by feelings of awkwardness as it is by the strong convictions and
ready enthusiasm of earlier times. The effect has been reinforced by the restructuring steadily
taking place in the international order. Whatever the shortcomings of the United Nations system
in its present form, and however handicapped its ability to take collective military action against
aggression, no one can mistake the fact that the fetish of absolute national sovereignty is on its
way to extinction.
Racial and ethnic prejudices have been subjected to equally summary treatment by historical
processes that have little patience left for such pretensions. Here, rejection of the past has been
especially decisive. Racism is now tainted by its association with the horrors of the twentieth
century to the degree that it has taken on something of the character of a spiritual disease. While
surviving as a social attitude in many parts of the world—and as a blight on the lives of a
signiﬁcant segment of humankind—racial prejudice has become so universally condemned in
principle that no body of people can any longer safely allow themselves to be identiﬁed with it.
It is not that a dark past has been erased and a new world of light has suddenly been born.
Vast numbers of people continue to endure the effects of ingrained prejudices of ethnicity, gender,
nation, caste and class. All the evidence indicates that such injustices will long persist as the
institutions and standards that humanity is devising only slowly become empowered to construct
a new order of relationships and to bring relief to the oppressed. The point, rather, is that a
threshold has been crossed from which there is no credible possibility of return. Fundamental
principles have been identiﬁed, articulated, accorded broad publicity and are becoming
progressively incarnated in institutions capable of imposing them on public behaviour. There is no
doubt that, however protracted and painful the struggle, the outcome will be to revolutionize
relationships among all peoples, at the grassroots level.
* * *
As the twentieth century opened, the prejudice that seemed more likely than any other to
succumb to the forces of change was that of religion. In the West, scientiﬁc advances had already
dealt rudely with some of the central pillars of sectarian exclusivity. In the context of the
transformation taking place in the human race’s conception of itself, the most promising new
religious development seemed to be the interfaith movement. In 1893, the World’s Columbian
Exposition surprised even its ambitious organizers by giving birth to the famed “Parliament of
Religions”, a vision of spiritual and moral consensus that captured the popular imagination on all
continents and managed to eclipse even the scientiﬁc, technological and commercial wonders that
the Exposition celebrated.
Brieﬂy, it appeared that ancient walls had fallen. For inﬂuential thinkers in the ﬁeld of
religion, the gathering stood unique, “unprecedented in the history of the world”. The Parliament
had, its distinguished principal organizer said, “emancipated the world from bigotry”. An
imaginative leadership, it was conﬁdently predicted, would seize the opportunity and awaken in
the earth’s long-divided religious communities a spirit of brotherhood that could provide the
needed moral underpinnings for the new world of prosperity and progress. Thus encouraged,
interfaith movements of every kind took root and ﬂourished. A vast literature, available in many
languages, introduced an ever wider public, believers and non-believers alike, to the teachings of
all the major faiths, an interest picked up in due course by radio, television, ﬁlm and eventually
the Internet. Institutions of higher learning launched degree programmes in the study of
comparative religion. By the time the century ended, interfaith worship services, unthinkable only
a few decades earlier, were becoming commonplace.
Alas, it is clear that these initiatives lack both intellectual coherence and spiritual
commitment. In contrast to the processes of uniﬁcation that are transforming the rest of
humanity’s social relationships, the suggestion that all of the world’s great religions are equally
valid in nature and origin is stubbornly resisted by entrenched patterns of sectarian thought. The
progress of racial integration is a development that is not merely an expression of sentimentality
or strategy but arises from the recognition that the earth’s peoples constitute a single species
whose many variations do not themselves confer any advantage or impose any handicap on
individual members of the race. The emancipation of women, likewise, has entailed the
willingness of both society’s institutions and popular opinion to acknowledge that there are no
acceptable grounds—biological, social or moral—to justify denying women full equality with men,
and girls equal educational opportunities with boys. Nor does appreciation of the contributions
that some nations are making to the shaping of an evolving global civilization support the
inherited illusion that other nations have little or nothing to bring to the effort.
So fundamental a reorientation religious leadership appears, for the most part, unable to
undertake. Other segments of society embrace the implications of the oneness of humankind, not
only as the inevitable next step in the advancement of civilization, but as the fulﬁlment of lesser
identities of every kind that our race brings to this critical moment in our collective history. Yet,
the greater part of organized religion stands paralyzed at the threshold of the future, gripped in
those very dogmas and claims of privileged access to truth that have been responsible for creating
some of the most bitter conﬂicts dividing the earth’s inhabitants.
The consequences, in terms of human well-being, have been ruinous. It is surely unnecessary
to cite in detail the horrors being visited upon hapless populations today by outbursts of
fanaticism that shame the name of religion. Nor is the phenomenon a recent one. To take only
one of many examples, Europe’s sixteenth century wars of religion cost that continent the lives of
some thirty percent of its entire population. One must wonder what has been the longer term
harvest of the seeds planted in popular consciousness by the blind forces of sectarian dogmatism
that inspired such conﬂicts.
To this accounting must be added a betrayal of the life of the mind which, more than any
other factor, has robbed religion of the capacity it inherently possesses to play a decisive role in
the shaping of world affairs. Locked into preoccupation with agendas that disperse and vitiate
human energies, religious institutions have too often been the chief agents in discouraging
exploration of reality and the exercise of those intellectual faculties that distinguish humankind.
Denunciations of materialism or terrorism are of no real assistance in coping with the
contemporary moral crisis if they do not begin by addressing candidly the failure of responsibility
that has left believing masses exposed and vulnerable to these inﬂuences.
Such reﬂections, however painful, are less an indictment of organized religion than a reminder
of the unique power it represents. Religion, as we are all aware, reaches to the roots of motivation.
When it has been faithful to the spirit and example of the transcendent Figures who gave the
world its great belief systems, it has awakened in whole populations capacities to love, to forgive,
to create, to dare greatly, to overcome prejudice, to sacriﬁce for the common good and to discipline
the impulses of animal instinct. Unquestionably, the seminal force in the civilizing of human
nature has been the inﬂuence of the succession of these Manifestations of the Divine that extends
back to the dawn of recorded history.
This same force, that operated with such effect in ages past, remains an inextinguishable
feature of human consciousness. Against all odds, and with little in the way of meaningful
encouragement, it continues to sustain the struggle for survival of uncounted millions, and to raise
up in all lands heroes and saints whose lives are the most persuasive vindication of the principles
contained in the scriptures of their respective faiths. As the course of civilization demonstrates,
religion is also capable of profoundly inﬂuencing the structure of social relationships. Indeed, it
would be difﬁcult to think of any fundamental advance in civilization that did not derive its moral
thrust from this perennial source. Is it conceivable, then, that passage to the culminating stage in
the millennia-long process of the organization of the planet can be accomplished in a spiritual
vacuum? If the perverse ideologies let loose on our world during the century just past contributed
nothing else, they demonstrated conclusively that the need cannot be met by alternatives that lie
within the power of human invention.
* * *
The implications for today are summed up by Bahá’u’lláh in words written over a century ago and
widely disseminated in the intervening decades:
There can be no doubt whatever that the peoples of the world, of whatever race or
religion, derive their inspiration from one heavenly Source, and are the subjects of one God.
The difference between the ordinances under which they abide should be attributed to the
varying requirements and exigencies of the age in which they were revealed. All of them,
except a few which are the outcome of human perversity, were ordained of God, and are a
reﬂection of His Will and Purpose. Arise and, armed with the power of faith, shatter to pieces
the gods of your vain imaginings, the sowers of dissension amongst you. Cleave unto that
which draweth you together and uniteth you.
Such an appeal does not call for abandonment of faith in the fundamental verities of any of
the world’s great belief systems. Far otherwise. Faith has its own imperative and is its own
justiﬁcation. What others believe—or do not believe—cannot be the authority in any individual
conscience worthy of the name. What the above words do unequivocally urge is renunciation of all
those claims to exclusivity or ﬁnality that, in winding their roots around the life of the spirit, have
been the greatest single factor in suffocating impulses to unity and in promoting hatred and
violence.
It is to this historic challenge that we believe leaders of religion must respond if religious
leadership is to have meaning in the global society emerging from the transformative experiences
of the twentieth century. It is evident that growing numbers of people are coming to realize that
the truth underlying all religions is in its essence one. This recognition arises not through a
resolution of theological disputes, but as an intuitive awareness born from the ever widening
experience of others and from a dawning acceptance of the oneness of the human family itself.
Out of the welter of religious doctrines, rituals and legal codes inherited from vanished worlds,
there is emerging a sense that spiritual life, like the oneness manifest in diverse nationalities,
races and cultures, constitutes one unbounded reality equally accessible to everyone. In order for
this diffuse and still tentative perception to consolidate itself and contribute effectively to the
building of a peaceful world, it must have the wholehearted conﬁrmation of those to whom, even
at this late hour, masses of the earth’s population look for guidance.
There are certainly wide differences among the world’s major religious traditions with respect
to social ordinances and forms of worship. Given the thousands of years during which successive
revelations of the Divine have addressed the changing needs of a constantly evolving civilization,
it could hardly be otherwise. Indeed, an inherent feature of the scriptures of most of the major
faiths would appear to be the expression, in some form or other, of the principle of religion’s
evolutionary nature. What cannot be morally justiﬁed is the manipulation of cultural legacies that
were intended to enrich spiritual experience, as a means to arouse prejudice and alienation. The
primary task of the soul will always be to investigate reality, to live in accordance with the truths
of which it becomes persuaded and to accord full respect to the efforts of others to do the same.
It may be objected that, if all the great religions are to be recognized as equally Divine in
origin, the effect will be to encourage, or at least to facilitate, the conversion of numbers of people
from one religion to another. Whether or not this is true, it is surely of peripheral importance
when set against the opportunity that history has at last opened to those who are conscious of a
world that transcends this terrestrial one—and against the responsibility that this awareness
imposes. Each of the great faiths can adduce impressive and credible testimony to its efﬁcacy in
nurturing moral character. Similarly, no one could convincingly argue that doctrines attached to
one particular belief system have been either more or less proliﬁc in generating bigotry and
superstition than those attached to any other. In an integrating world, it is natural that patterns of
response and association will undergo a continuous process of shifting, and the role of institutions,
of whatever kind, is surely to consider how these developments can be managed in a way that
promotes unity. The guarantee that the outcome will ultimately be sound—spiritually, morally and
socially—lies in the abiding faith of the unconsulted masses of the earth’s inhabitants that the
universe is ruled not by human caprice, but by a loving and unfailing Providence.
Together with the crumbling of barriers separating peoples, our age is witnessing the
dissolution of the once insuperable wall that the past assumed would forever separate the life of
Heaven from the life of Earth. The scriptures of all religions have always taught the believer to
see in service to others not only a moral duty, but an avenue for the soul’s own approach to God.
Today, the progressive restructuring of society gives this familiar teaching new dimensions of
meaning. As the age-old promise of a world animated by principles of justice slowly takes on the
character of a realistic goal, meeting the needs of the soul and those of society will increasingly be
seen as reciprocal aspects of a mature spiritual life.
If religious leadership is to rise to the challenge that this latter perception represents, such
response must begin by acknowledging that religion and science are the two indispensable
knowledge systems through which the potentialities of consciousness develop. Far from being in
conﬂict with one another, these fundamental modes of the mind’s exploration of reality are
mutually dependent and have been most productive in those rare but happy periods of history
when their complementary nature has been recognized and they have been able to work together.
The insights and skills generated by scientiﬁc advance will have always to look to the guidance of
spiritual and moral commitment to ensure their appropriate application; religious convictions, no
matter how cherished they may be, must submit, willingly and gratefully, to impartial testing by
scientiﬁc methods.
We come ﬁnally to an issue that we approach with some difﬁdence as it touches most directly
on conscience. Among the many temptations the world offers, the test that has, not surprisingly,
preoccupied religious leaders is that of exercising power in matters of belief. No one who has
dedicated long years to earnest meditation and study of the scriptures of one or another of the
great religions requires any further reminder of the oft-repeated axiom regarding the potentiality
of power to corrupt and to do so increasingly as such power grows. The unheralded inner victories
won in this respect by unnumbered clerics all down the ages have no doubt been one of the chief
sources of organized religion’s creative strength and must rank as one of its highest distinctions.
To the same degree, surrender to the lure of worldly power and advantage, on the part of other
religious leaders, has cultivated a fertile breeding ground for cynicism, corruption and despair
among all who observe it. The implications for the ability of religious leadership to fulﬁl its social
responsibility at this point in history need no elaboration.
* * *
Because it is concerned with the ennobling of character and the harmonizing of relationships,
religion has served throughout history as the ultimate authority in giving meaning to life. In every
age, it has cultivated the good, reproved the wrong and held up, to the gaze of all those willing to
see, a vision of potentialities as yet unrealized. From its counsels the rational soul has derived
encouragement in overcoming limits imposed by the world and in fulﬁlling itself. As the name
implies, religion has simultaneously been the chief force binding diverse peoples together in ever
larger and more complex societies through which the individual capacities thus released can ﬁnd
expression. The great advantage of the present age is the perspective that makes it possible for
the entire human race to see this civilizing process as a single phenomenon, the ever-recurring
encounters of our world with the world of God.
Inspired by this perspective, the Bahá’í community has been a vigorous promoter of interfaith
activities from the time of their inception. Apart from cherished associations that these activities
create, Bahá’ís see in the struggle of diverse religions to draw closer together a response to the
Divine Will for a human race that is entering on its collective maturity. The members of our
community will continue to assist in every way we can. We owe it to our partners in this common
effort, however, to state clearly our conviction that interfaith discourse, if it is to contribute
meaningfully to healing the ills that afﬂict a desperate humanity, must now address honestly and
This document has been downloaded from the Bahá’í Reference Library. You are free to use its content subject to the terms of use found at www.bahai.org/legalwithout further evasion the implications of the over-arching truth that called the movement into
being: that God is one and that, beyond all diversity of cultural expression and human
interpretation, religion is likewise one.
With every day that passes, danger grows that the rising ﬁres of religious prejudice will ignite
a worldwide conﬂagration the consequences of which are unthinkable. Such a danger civil
government, unaided, cannot overcome. Nor should we delude ourselves that appeals for mutual
tolerance can alone hope to extinguish animosities that claim to possess Divine sanction. The
crisis calls on religious leadership for a break with the past as decisive as those that opened the
way for society to address equally corrosive prejudices of race, gender and nation. Whatever
justiﬁcation exists for exercising inﬂuence in matters of conscience lies in serving the well-being
of humankind. At this greatest turning point in the history of civilization, the demands of such
service could not be more clear. “The well-being of mankind, its peace and security, are
unattainable”, Bahá’u’lláh urges, “unless and until its unity is ﬁrmly established.”
[signed: The Universal House of Justice]