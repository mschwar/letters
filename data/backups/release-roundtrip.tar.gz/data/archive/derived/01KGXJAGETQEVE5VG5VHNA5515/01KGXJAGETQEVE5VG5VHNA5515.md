THE UNIVERSAL HOUSE OF JUSTICE
28 November 2023
To the Bahá’ís of the World
Dearly loved Friends,
On 27 November 2021, in the middle of the still, dark night, nearly six hundred
representatives of National Spiritual Assemblies and Regional Bahá’í Councils gathered, together
with members of the Universal House of Justice and the International Teaching Centre, as well as
the staff at the Bahá’í World Centre, to commemorate with due solemnity, in the precincts of His
Holy Shrine, the centenary of the passing of ‘Abdu’l-Bahá. Throughout that night, with the turn of
the globe, Bahá’í communities worldwide also gathered in reverent devotion, in neighbourhoods
and villages, towns and cities, to pay homage to a Figure without parallel in religious history, and
in contemplation of the century of achievement that He Himself had set in motion.
This community—the people of Bahá, ardent lovers of ‘Abdu’l-Bahá—now millions strong, has
today spread to some one hundred thousand localities in 235 countries and territories. It has
emerged from obscurity to occupy its place on the world stage. It has raised a network of
thousands of institutions, from the grassroots to the international level, uniting divers peoples in
the common purpose of giving expression to Bahá’u’lláh’s teachings for spiritual transformation
and social progress. In many a region, its pattern of building vibrant local communities has
embraced thousands—and in some, tens of thousands—of souls. In such settings, a new way of life
is taking shape, distinguished by its devotional character; the commitment of youth to education
and service; purposeful conversation among families, friends, and acquaintances on themes of
spiritual and social import; and collective endeavours for material and social progress. The Sacred
Writings of the Faith have been translated into more than eight hundred languages. The raising of
national and local Mashriqu’l-Adhkárs heralds the appearance of thousands of future centres
dedicated to worship and service. The world spiritual and administrative centre of the Faith has
been established across the twin holy cities of ‘Akká and Haifa. And despite the community’s
current, all too obvious limitations when viewed in relation to its ideals and highest aspirations—
as well as the distance separating it from the attainment of its ultimate objective, the realization
of the oneness of humankind—its resources, its institutional capacity, its ability to sustain
systematic growth and development, its engagement with like-minded institutions, and its
involvement in and constructive inﬂuence on society stand at an unprecedented height of
historical achievement.
How far has the Faith come from that moment, a century ago, when ‘Abdu’l-Bahá departed
from this world! At dawn on that woeful day, the news of His passing spread across the city of
Haifa, consuming the hearts with grief. Thousands gathered for His funeral: young and old, high
and low, distinguished ofﬁcials and the masses—Jews and Muslims, Druze and Christians, as well
as Bahá’ís—a gathering the like of which the city had never witnessed. In the eyes of the world,
‘Abdu’l-Bahá had been a champion of universal peace and the oneness of humanity, a defender of
the oppressed and promoter of justice. To the people of both ‘Akká and Haifa, He was a loving
father and friend, a wise counsellor and a refuge for all in need. At His funeral they poured out
fervent expressions of love and lamentation.
Naturally, however, it was the Bahá’ís who most keenly felt His loss. He was the precious gift
bestowed by the Manifestation of God to guide and protect them, the Centre and Pivot of
Bahá’u’lláh’s peerless and all-enfolding Covenant, the perfect Exemplar of His teachings, the
unerring Interpreter of His Word, the embodiment of every Bahá’í ideal. Over the span of His life,
‘Abdu’l-Bahá laboured tirelessly in service to Bahá’u’lláh, fulﬁlling, in its entirety, His Father’s
sacred trust. He faithfully nurtured and protected the precious seed that had been planted. He
sheltered the Cause in the cradle of its birth and, guiding its spread in the West, established there
the cradle of its administration. He set ﬁrm the footsteps of the believers and raised up a cohort of
champions and saints. With His own hands, He interred the holy remains of the Báb in the
mausoleum He raised on Mount Carmel, devotedly tended the twin Holy Shrines, and laid the
foundations of the Faith’s world administrative centre. He safeguarded the Faith from its avowed
enemies, internal and external. He revealed the precious Charter for sharing Bahá’u’lláh’s
teachings with all peoples across the globe, as well as the Charter that called into being and set in
motion the processes of the Administrative Order. His life spanned the entire period of the Heroic
Age inaugurated by the declaration of the Báb; His ascension ushered in a new Age whose
features were as yet unknown to the believers. What was to befall His loved ones? Without Him,
without His continual guidance, the future seemed uncertain and bleak.
Devastated by the news of ‘Abdu’l-Bahá’s passing, His grandson Shoghi Effendi hastened
from his studies in England to the Holy Land, where he received a second stunning blow. ‘Abdu’l-
Bahá had appointed him as the Guardian and Head of the Faith, entrusting the Bahá’í world to his
care. In grief and agony, but sustained by the unfailing solicitude of Bahá’u’lláh’s beloved daughter
Bahíyyih Khánum, Shoghi Effendi donned the heavy mantle of his ofﬁce and began to assess the
conditions and prospects of the ﬂedgling community.
The announcement of Shoghi Effendi’s appointment as the Guardian was received with relief,
gratitude, and declarations of fealty by the body of the believers. The anguish of their separation
from the Master was assuaged by the assurances in His Will and Testament that He had not left
them alone. A disloyal few, however, challenged ‘Abdu’l-Bahá’s chosen heir and, motivated by
their own ambitions and ego, rose against him. Their betrayal at that critical moment of transition
was compounded by the fresh machinations of the avowed opponents of the Master. Yet, although
hard-pressed by such heartache and trials, and in the face of other formidable obstacles, Shoghi
Effendi began to mobilize the members of the widely scattered Bahá’í communities to begin the
monumental task of laying the foundations of the Administrative Order. Individuals previously
galvanized by the unique personality of ‘Abdu’l-Bahá gradually began to coordinate their efforts in
a common enterprise under the patient yet resolute guidance of the Guardian.
As the Bahá’ís began to take on their new responsibilities, Shoghi Effendi impressed upon
them how rudimentary was their grasp, as yet, of the sacred Revelation in their possession and
how daunting the challenges before them. “How vast is the Revelation of Bahá’u’lláh! How great
the magnitude of His blessings showered upon humanity in this day!” he wrote. “And yet, how
poor, how inadequate our conception of their signiﬁcance and glory! This generation stands too
close to so colossal a Revelation to appreciate, in their full measure, the inﬁnite possibilities of His
Faith, the unprecedented character of His Cause, and the mysterious dispensations of His
Providence.” “The contents of the Will of the Master are far too much for the present generation to
comprehend”, his secretary wrote on his behalf. “It needs at least a century of actual working
before the treasures of wisdom hidden in it can be revealed.” To comprehend the nature and
dimensions of Bahá’u’lláh’s vision of a new World Order, he explained, “We must trust to time,
and the guidance of God’s Universal House of Justice, to obtain a clearer and fuller understanding
of its provisions and implications.”
The present moment, following, as it does, the completion of a full century of “actual
working”, offers a propitious vantage point from which to garner new insights. And so we have
chosen the occasion of this anniversary to pause to reﬂect with you on the wisdom enshrined in
the provisions of the Will and Testament, to trace the course of the Faith’s unfoldment and
observe the coherence of the stages of its organic development, to discern the possibilities
inherent in the processes driving its progress, and to appreciate its promise for the decades ahead
as its power to reshape society is increasingly made manifest in the world through the growing
impact of Bahá’u’lláh’s stupendous Revelation.
Translating what is written into reality and action
Bahá’u’lláh’s purpose is to usher in a new stage in human development—the organic and
spiritual unity of the peoples and nations of the world—signalizing thereby the coming of age of
the human race and characterized, in the fullness of time, by the emergence of a world civilization
and culture. To this end, He revealed His teachings for the inner and outer transformation of
human life. “Every verse which this Pen hath revealed is a bright and shining portal that
discloseth the glories of a saintly and pious life, of pure and stainless deeds”, He stated. And in
countless Tablets He, the Divine Physician, diagnosed the ills afﬂicting humanity and set forth His
healing remedy for “the elevation, the advancement, the education, the protection and the
regeneration of the peoples of the earth”. Bahá’u’lláh explained that “The summons and the
message which We gave were never intended to reach or to beneﬁt one land or one people only.”
“It is incumbent upon every man of insight and understanding”, He wrote, “to strive to translate
that which hath been written into reality and action…. Blessed and happy is he that ariseth to
promote the best interests of the peoples and kindreds of the earth.”
The task of building a mature, peaceful, just, and united world is a vast undertaking in which
every people and nation must be able to participate. The Bahá’í community welcomes all to join
in this endeavour as protagonists in a spiritual enterprise that can overcome the forces of
disintegration eroding the old social order and give tangible form to an integrative process that will
lead to the unfoldment of a new order in its stead. The Formative Age is that critical period in the
Faith’s development in which the friends increasingly come to appreciate the mission with which
Bahá’u’lláh has entrusted them, deepen their understanding of the meaning and implications of
His revealed Word, and systematically cultivate capacity—their own and that of others—in order to
put into practice His teachings for the betterment of the world.
From the beginning of his ministry, Shoghi Effendi guided the Bahá’ís in their efforts to gain a
deeper understanding of their mission, which would deﬁne their identity and purpose. He
explicated for them the meaning of the coming of Bahá’u’lláh, His vision for humanity, the history
of the Cause, the processes reshaping society, and the part the Bahá’ís must play in contributing
to the advancement of humankind. He outlined the nature of the development of the Bahá’í
community so the friends would appreciate that it would undergo many transformations, often
unexpected, over decades and centuries. He also described the dialectic of crisis and victory,
preparing them for the tortuous path they must traverse. He called upon the Bahá’ís to reﬁne
their characters and hone their minds to meet the challenges of building a new world. He urged
them not to despair when encountering the problems of a nascent and rapidly evolving
community or the privations and the deteriorating milieu of a tumultuous age, reminding them
that the full expression of the promises of Bahá’u’lláh lay in the future. He explained that the
Bahá’ís were to be as a leaven—a permeating and vivifying inﬂuence—that could inspire others to
arise and overcome entrenched patterns of divisiveness, conﬂict, and contest for power, so that the
highest aspirations of humanity could ultimately be achieved.
While consolidating these broad areas of understanding, the Guardian also guided the
believers, step by step, to learn how to effectively establish the structural basis of the
Administrative Order and systematically share Bahá’u’lláh’s teachings with others. He patiently
directed their efforts by gradually clarifying the nature, principles, and procedures which
characterize that Order, while raising their capacity for teaching the Faith, individually and
collectively. On each vital matter, he would provide direction and the believers would consult and
strive to apply his guidance, sharing their experiences with him and raising questions when they
faced perplexing problems and difﬁculties. Then, taking into consideration the accumulating
experience, the Guardian would offer additional guidance and elaborate the concepts and
principles that would enable the friends to adjust their action as needed, until their efforts proved
effective and could be applied more broadly. In their response to his guidance, the friends
demonstrated an unwavering faith in the truth of the revealed Word, an unfaltering trust in his
vision and infallible wisdom, and an unshakeable resolve to transform the various aspects of their
lives according to the pattern set out in the Teachings. In this way, a capacity for learning how to
apply the Teachings was gradually cultivated within the community. The efﬁcacy of this approach
was demonstrated most vividly at the climax of his ministry, when the Bahá’í world combined its
forces for the unprecedented achievements of the Ten Year Spiritual Crusade.
The efforts of Shoghi Effendi to set the believers on a path of learning were further extended,
after his passing, under the direction of the Universal House of Justice. By the ﬁnal years of the
ﬁrst century of the Formative Age, the essential aspects of a process of learning that was in a
ﬂedgling state at the beginning of that century were consciously grasped and systematically
implemented by Bahá’ís worldwide across the full range of their endeavours.
Today the Bahá’í community is distinguished by a mode of operation characterized by study,
consultation, action, and reﬂection. It is steadily increasing its capacity to apply the Teachings in a
variety of social spaces and to collaborate with those in the wider society who share a yearning to
revitalize the material and spiritual foundations of the social order. In the transformative alembic
of these spaces, to the extent possible, individuals and communities become protagonists of their
own development, an embrace of the oneness of humanity banishes prejudice and otherness, the
spiritual dimension of human life is fostered through adherence to principle and strengthening of
the community’s devotional character, and the capacity for learning is developed and directed
towards personal and social transformation. The effort to understand the implications of what
Bahá’u’lláh has revealed and to apply His healing remedy has now become more explicit, more
deliberate, and an indelible part of Bahá’í culture. The conscious grasp of the process of learning
and its extension worldwide, from the grassroots to the international arena, are among the ﬁnest
fruits of the ﬁrst century of the Formative Age. This process will increasingly inform the work of
every institution, community, and individual in the years ahead, as the Bahá’í world takes on ever-
greater challenges and releases in ever-greater measures the Faith’s society-building power.
In his efforts to assist the friends in their understanding of the development of the Faith and
their associated responsibilities, Shoghi Effendi referred to “the triple impulse generated through
the revelation of the Tablet of Carmel by Bahá’u’lláh and the Will and Testament as well as the
Tablets of the Divine Plan bequeathed by the Centre of His Covenant—the three Charters which
have set in motion three distinct processes, the ﬁrst operating in the Holy Land for the
development of the institutions of the Faith at its World Centre and the other two, throughout the
rest of the Bahá’í world, for its propagation and the establishment of its Administrative Order”.
The processes associated with each of these Divine Charters are interdependent and mutually
reinforcing. The Administrative Order is the chief instrument for the prosecution of the Divine
Plan, while the Plan is the most potent agency for the development of the Faith’s administrative
structure. Advances at the World Centre, the heart and nerve centre of the administration, exert a
pronounced inﬂuence on the body of the worldwide community and are in turn affected by its
vitality. The Bahá’í world constantly evolves and develops organically as individuals, communities,
and institutions strive to translate into reality the truths of Bahá’u’lláh’s Revelation. Now, at the
end of the ﬁrst century of the Formative Age, the Bahá’í world is able to apprehend more fully the
implications inherent in these immortal Charters for the development of the Faith. And because it
has increased its understanding of the process in which it is engaged, it can better appreciate its
own experience over the past century and can act more effectively to achieve Bahá’u’lláh’s
intended purpose for humanity in the decades and centuries that lie ahead.
The perpetuation of the Covenant
To preserve the unity of His Faith, maintain the integrity and ﬂexibility of His teachings, and
guarantee the progress of all humanity, Bahá’u’lláh established a Covenant with His followers
that is unique in the annals of religious history for its authority and its explicit and
comprehensive nature. In His Most Holy Book and in the Book of His Covenant, as well as in
other Tablets, Bahá’u’lláh instructed that after His passing the friends should turn to ‘Abdu’l-
Bahá, the Centre of that Covenant, to guide the affairs of the Faith. In His Will and Testament,
‘Abdu’l-Bahá perpetuated the Covenant by laying down the provisions for the Administrative
Order ordained in Bahá’u’lláh’s Writings, thereby ensuring the continuation of authority and
leadership through the twin institutions of the Guardianship and the Universal House of Justice,
as well as a sound relationship between individuals and institutions within the Faith.
History has amply demonstrated that religion can serve either as a powerful instrument for
cooperation to propel the advancement of civilization, or as a source of conﬂict that yields
incalculable harm. The unifying and civilizing power of religion begins to decline as the followers
come to disagree on the meaning and application of the divine teachings, and the community of
the faithful eventually becomes divided into contending sects and denominations. The purpose of
Bahá’u’lláh’s Revelation is to establish the oneness of humanity and unite all peoples, and this
last and highest stage in the evolution of society cannot be achieved if the Bahá’í Faith succumbs
to the malady of sectarianism and the dilution of the divine Message witnessed in the past. If
Bahá’ís “cannot unite around one point”, ‘Abdu’l-Bahá observes, “how will they be able to bring
about the unity of mankind?” And He afﬁrms: “Today the dynamic power of the world of
existence is the power of the Covenant which like unto an artery pulsateth in the body of the
contingent world and protecteth Bahá’í unity.”
Foremost among the achievements of the past century is the victory of the Covenant, which
both protected the Faith from division and propelled it to embrace and contribute to the
empowerment of all peoples and nations. Bahá’u’lláh’s penetrating question that lies at the heart
of religion—“Where shalt thou secure the cord of thy faith and fasten the tie of thine
obedience?”—takes on a new and vital signiﬁcance for those who recognize Him as the
Manifestation of God for this Day. It is a call for ﬁrmness in the Covenant. The response of the
Bahá’í community has been unyielding adherence to the provisions of ‘Abdu’l-Bahá’s Will and
Testament. Unlike relationships of worldly power in which a sovereign entity compels obedience,
the relationship between the Manifestation of God and the believers, and between the authority
designated by the Covenant and the community, is governed by conscious knowledge and love. In
recognizing Bahá’u’lláh, a believer enters voluntarily into His Covenant as an act of free
conscience and, out of love for Him, remains steadfast in adherence to its requirements. At the
close of the ﬁrst century of the Formative Age, the Bahá’í world has come to more fully
understand and act upon the provisions of Bahá’u’lláh’s Covenant, and a distinctive set of
relationships has been established among the believers that unify and direct their energies in
pursuit of their sacred mission. This achievement, like so many others, was the fruit of crises
overcome.
The existence of the Covenant does not mean that no one will ever attempt to divide the
Faith, cause damage to it, or retard its progress. But it does guarantee that every such attempt is
foredoomed to fail. Following the passing of Bahá’u’lláh, some ambitious individuals, including the
brothers of ‘Abdu’l-Bahá, tried to usurp the authority granted to ‘Abdu’l-Bahá by Bahá’u’lláh and
sowed seeds of doubt within the community, testing and at times misleading those who wavered.
Shoghi Effendi, during his own ministry, was attacked not only by those who had broken the
Covenant and opposed ‘Abdu’l-Bahá, but also by some within the community who rejected the
validity of the Administrative Order and questioned the authority of the Guardianship. Years later,
when Shoghi Effendi passed away, a new attack upon the Covenant emerged when one
profoundly misguided individual, despite having served for many years as a Hand of the Cause of
God, made an unfounded and futile attempt to claim the Guardianship for himself, in spite of the
clear conditions set forth in the Will and Testament. After the election of the Universal House of
Justice, it too became a target of the active opponents of the Cause. In more recent decades, a few
from within the community, presenting themselves as more knowledgeable than others,
fruitlessly sought to reinterpret the Bahá’í teachings pertaining to the provisions of the Covenant
in order to cast doubt on the authority of the House of Justice and to claim certain prerogatives, in
the absence of a living Guardian, that would enable them to drive the affairs of the Faith in a
direction of their own choosing.
Over a century, then, the Covenant established by Bahá’u’lláh and perpetuated by ‘Abdu’l-
Bahá was attacked in various ways by internal and external opponents, but ultimately to no avail.
While, each time, some individuals were misled or became disaffected, the attacks failed to divert
or redeﬁne the Cause or to make a permanent breach in the community. In each instance, by
turning to the designated centre of authority at the time—‘Abdu’l-Bahá, the Guardian, or the
Universal House of Justice—questions were answered and problems resolved. As the body of
believers grew in its understanding of and ﬁrmness in the Covenant, it learned to become
impervious to the types of attacks and misrepresentations that, in an earlier era, had threatened
the Faith’s very existence and purpose. The integrity of the Cause of Bahá’u’lláh remains ever
secure.
Every generation of Bahá’ís, however great their spiritual perception, will inevitably have a
circumscribed comprehension of the full implications of Bahá’u’lláh’s teachings, owing to the
limitations of their own historical circumstances and the particular stage of the Faith’s organic
development. In the Heroic Age of the Faith, for example, the believers had to navigate what they
surely experienced at times as a bewildering and revolutionary series of transitions from the
Dispensation of the Báb to that of Bahá’u’lláh, and then to the ministry of ‘Abdu’l-Bahá—all of
which, with hindsight and the illumination provided by Shoghi Effendi, are now easily
comprehended as sequential acts in a single, divinely unfolding drama. So too, today, after the
tireless labours of the community over a full century, the ﬁrst of the Formative Age, it is possible
to grasp more completely the signiﬁcance, purpose, and inviolability of the Covenant—that
priceless bequest of Bahá’u’lláh to His followers. The hard-won understanding of the nature of the
Covenant and the ﬁrmness that such insight engenders and sustains will continue to be essential
for unity and progress over the course of the Dispensation.
It is now evident and ﬁrmly established that Bahá’u’lláh’s Covenant provides for two
authoritative centres. The ﬁrst is the Book: the Revelation of Bahá’u’lláh, along with the body of
works of ‘Abdu’l-Bahá and Shoghi Effendi that constitute authoritative interpretation and
explication of the Creative Word. With the passing of Shoghi Effendi, more than a century of the
extension of that authoritative centre came to a close. Yet the existence of the Book ensures that
the Revelation is available to every believer, indeed to all humanity, unadulterated by human
misinterpretations or accretions.
The second authoritative centre is the Universal House of Justice, which, as the Sacred
Writings afﬁrm, is under the care and unerring guidance of Bahá’u’lláh and the Báb. “Let it not be
imagined that the House of Justice will take any decision according to its own concepts and
opinions”, ‘Abdu’l-Bahá explains. “God forbid! The Supreme House of Justice will take decisions
and establish laws through the inspiration and conﬁrmation of the Holy Spirit, because it is in the
safekeeping and under the shelter and protection of the Ancient Beauty”. “God will verily inspire
them with whatsoever He willeth,” Bahá’u’lláh proclaims. “They, and not the body of those who
either directly or indirectly elect them,” Shoghi Effendi states, “have thus been made the recipients
of the divine guidance which is at once the life-blood and ultimate safeguard of this Revelation.”
The powers and duties with which the House of Justice has been invested encompass all that
is necessary to ensure the fulﬁlment of Bahá’u’lláh’s purpose for humanity. For more than a half
century, the Bahá’í world has witnessed ﬁrst-hand their range and expression, including the
promulgation of the Law of God, the conservation and dissemination of the Bahá’í Sacred Writings,
the raising of the Administrative Order and the creation of new institutions, the design of
successive stages in the unfoldment of the Divine Plan, and the protection of the Faith and
safeguarding of its unity, as well as efforts conducive to the preservation of human honour, the
progress of the world, and the illumination of its peoples. The elucidations of the House of Justice
resolve all difﬁcult problems, questions that are obscure, problems that have caused difference, and
matters not expressly recorded in the Book. The House of Justice will provide guidance throughout
the Dispensation according to the exigencies of the time, thus ensuring that the Cause, even as a
living organism, is able to adapt to the needs and requirements of an ever-changing society. And it
guarantees that no one can alter the nature of Bahá’u’lláh’s message or change the essential
characteristics of the Cause.
In the Kitáb-i-Íqán, Bahá’u’lláh asks, “What ‘oppression’ is more grievous than that a soul
seeking the truth, and wishing to attain unto the knowledge of God, should know not where to go
for it and from whom to seek it?” A world largely oblivious to the light of Bahá’u’lláh’s Revelation
ﬁnds itself increasingly divided and disoriented on matters of truth, morality, identity, and purpose,
and bewildered by the accelerating and corrosive effect of the forces of disintegration. For the
Bahá’í community, however, the Covenant offers a source of clarity and refuge, of freedom and
strength. Every believer is free to explore the ocean of Bahá’u’lláh’s Revelation, to come to
personal conclusions, to humbly share insights with others, and to strive to apply the Teachings
day by day. Collective endeavour is harmonized and focused through consultation and the guidance
of the institutions, transforming bonds between individuals, within families, and among
communities, and fostering social progress.
Out of love for Bahá’u’lláh and reassured by His explicit instructions, individuals,
communities, and institutions ﬁnd in the two authoritative centres of the Covenant the necessary
guidance for the unfoldment of the Faith and the preservation of the integrity of the Teachings. In
this way, the Covenant protects and preserves the process of dialogue and learning about the
meaning of the Revelation and the implementation of its prescriptions for humankind over the
course of the Dispensation, avoiding the detrimental effects of endless contention about meaning
and practice. As a result, the balanced relationships among individuals, communities, and
institutions are safeguarded and develop along their proper path, while all are enabled to attain to
their full potential and exercise their agency and prerogatives. Thus, the Bahá’í community can
unitedly advance and increasingly fulﬁl its vital purpose by investigating reality and generating
knowledge, extending the reach of its endeavours, and contributing to the advancement of
civilization. After more than a century, the truth of ‘Abdu’l-Bahá’s afﬁrmation is ever more
evident: “the axis of the oneness of the world of humanity is the power of the Covenant and
nothing else”.
The unfoldment of the Administrative Order
Beyond its perpetuation of the Covenant, ‘Abdu’l-Bahá’s Will and Testament laid the
foundation for another of the most signiﬁcant achievements of the ﬁrst century of the Formative
Age: the emergence and development of the Administrative Order, the child of the Covenant. In a
single century, the administration, which began with a focus on the establishment of elected
institutions, grew in breadth and complexity, unfolding throughout the world until it linked all
peoples, countries, and regions. The Writings of Bahá’u’lláh and ‘Abdu’l-Bahá that called these
institutions into being also provide the vision and spiritual mandate for these institutions to assist
humanity in constructing a just and peaceful world.
Through the Administrative Order of His Faith, Bahá’u’lláh has associated individuals,
communities, and institutions as protagonists in a system without precedent. In keeping with the
needs of an age of human maturity, He abrogated the historical practice whereby ecclesiastics held
the reins of religious authority, instructing the community of the faithful and directing its affairs.
In order to prevent the contest of competing ideologies, He set out the means for cooperation in
the search for truth and the pursuit of human well-being. In place of the quest for power over
others, He introduced arrangements that would cultivate the individual’s latent powers and their
expression in service to the common good. Trustworthiness, truthfulness, rectitude of conduct,
forbearance, love, and unity are among the spiritual qualities that form the basis of association
between the three protagonists of a new way of life, while efforts for social advancement are all
shaped by Bahá’u’lláh’s vision of the oneness of humanity.
At the time of ‘Abdu’l-Bahá’s passing, the institutions of the Faith consisted of a small
number of local Assemblies functioning in disparate ways. Only a handful of agencies operated
beyond a local level, and there were no National Spiritual Assemblies. Bahá’u’lláh had appointed
four Hands of the Cause in Iran, and ‘Abdu’l-Bahá directed their activities for the progress and
protection of the Faith, but He did not add to their number beyond four posthumous
appointments. Thus, up to that point, the Cause of Bahá’u’lláh, abundant in spirit and potential,
had yet to form the administrative machinery that would enable it to systematize its efforts.
In the ﬁrst months of his ministry, Shoghi Effendi considered establishing the House of Justice
immediately. Yet, after reviewing the state of the Faith worldwide, he quickly concluded that the
conditions required for the formation of the House of Justice were not yet in place. Instead, he
encouraged the Bahá’ís everywhere to concentrate their energies on raising Local and National
Spiritual Assemblies. “The National Spiritual Assemblies, like unto pillars, will be gradually and
ﬁrmly established in every country on the strong and fortiﬁed foundations of the Local
Assemblies”, he stated. “On these pillars, the mighty ediﬁce, the Universal House of Justice, will
be erected, raising high its noble frame above the world of existence.”
In helping the friends to understand their work to lay the foundations of their community,
Shoghi Effendi emphasized that the Administrative Order was not an end in itself, but an
instrument to canalize the spirit of the Faith. He highlighted its organic character, explaining that
Bahá’í administration “is only the ﬁrst shaping of what in future will come to be the social life
and laws of community living” and that “the believers are only just beginning to grasp and
practice it properly”. He also explained that the Administrative Order was the “nucleus and
pattern” of what would eventually become a new order for organizing the affairs of humanity
envisioned by Bahá’u’lláh. And thus, as the friends began to raise the administration, they could
appreciate that the relationships among individuals, communities, and institutions being
established would evolve in complexity, resulting in a growth in capacity over time as the Faith
expanded and generated a new pattern of life that could engage ever more broadly the peoples of
the world.
Through a steady exchange of correspondence, Shoghi Effendi guided the friends step by step
in their efforts to learn to apply the teachings pertaining to the administration, and to deepen
their understanding of its purpose, its necessity, its methods, its form, its principles, its ﬂexibility,
and the manner of its operation, while conﬁrming for them the explicit basis for such matters in
the Bahá’í Writings. He assisted them in developing the process of Bahá’í elections, establishing
and administering the Bahá’í Fund, arranging the National Convention, building the relationship
between the National and Local Assemblies, and a host of other matters. He dispelled the doubts
and hesitancy of those who struggled to appreciate the essential continuity between the culture
and practices of Bahá’í life during the time of ‘Abdu’l-Bahá and the steps that he, as Guardian,
was taking to lay the administrative foundations for the next stage of the Faith’s development. As
the believers managed their administrative affairs, he patiently answered their questions, resolved
problems, and fostered the collective life of the Bahá’í world community. Gradually the friends
learned to work in harmony, to uphold the decisions of their institutions and support their
progress, and to appreciate that both understanding and capacity for action would increase over
time. Local Assemblies began to operate according to consistent procedures for elections,
consultation, ﬁnancial affairs, and the conduct of community life. National Assemblies were
initially formed in the British Isles, Germany and Austria, India and Burma, Egypt and the Sudan,
the Caucasus, Turkistán, and the United States and Canada. In keeping with the organic nature of
the Administrative Order, National Assemblies were often established ﬁrst at a regional level,
encompassing more than one country, and only later at the level of a nation or territory as the
number of believers and Local Assemblies multiplied. In their wake, a host of different committees
were constituted, appointed at both the local and national levels, to advance collective efforts
across a range of areas including teaching, translation, publishing, education, pioneering, and
organizing Nineteen Day Feasts and Holy Days.
After three decades devoted to constructing the administration at the local and national levels,
in the ﬁnal years of his life Shoghi Effendi inaugurated a new stage in the development of the
Administrative Order by bringing into being institutions at the international and continental
levels. It began with the “long anticipated rise and establishment of the World Administrative
Centre of the Faith of Bahá’u’lláh in Holy Land”. In 1951, he proclaimed the formation of the
International Bahá’í Council. This new institution, he explained, would evolve through various
stages preparatory to its transformation and efﬂorescence into the Universal House of Justice.
This dramatic development was soon followed, at the end of the same year, by Shoghi
Effendi’s appointment of twelve Hands of the Cause of God, equally represented on three
continents and in the Holy Land—the ﬁrst contingent of Hands of the Cause to be raised up in
conformity with the provisions of ‘Abdu’l-Bahá’s Will and Testament. These distinguished
individuals were appointed to advance the work of the propagation and protection of the Faith.
The existence of an institution that plays such a vital role in furthering the interests of the Cause,
but which has no legislative, executive, or judicial authority and is entirely devoid of priestly
functions or the right to make authoritative interpretations, is a feature of Bahá’í administration
unparalleled in the religions of the past. After many years of nurturing the system of elected
Assemblies and their associated agencies, Shoghi Effendi began to shape this appointed
institution, and to guide the friends to understand, welcome, and support its unique functions. The
appointment, in 1952, of a second contingent of Hands raised their number to nineteen. The
Auxiliary Boards, whose members served as deputies to the Hands in each continent, were
established in 1954. Even up to the ﬁnal days of his life, the Guardian continued to expand this
institution, appointing a ﬁnal contingent of Hands to raise their number to twenty-seven, and
establishing an Auxiliary Board for Protection to complement the Board for Propagation.
In reﬂecting upon their efforts to build up the nascent form of the administration, Shoghi
Effendi had explained to the believers that much of what was instituted under his guidance was
temporary and that it was the function of the Universal House of Justice “to lay more deﬁnitely
the broad lines that must guide the future activities and administration” of the Faith. On another
occasion he wrote that “when this Supreme Body will have been properly established, it will have
to consider afresh the whole situation, and lay down the principle which shall direct, so long as it
deems advisable, the affairs of the Cause”.
Following the unexpected passing of Shoghi Effendi in November 1957, responsibility for the
affairs of the Cause fell for a brief time to the Hands of the Cause of God. Only a month earlier
they had been designated by the Guardian as “the Chief Stewards of Bahá’u’lláh’s embryonic
World Commonwealth, who have been invested by the unerring Pen of the Centre of His
Covenant with the dual function of guarding over the security, and of ensuring the propagation, of
His Father’s Faith”. The Hands faithfully and uncompromisingly adhered to the course laid out by
the Guardian. Under their stewardship, the number of National Assemblies was raised from
twenty-six to ﬁfty-six, and by 1961 the steps he had described for the transition of the
International Bahá’í Council from an appointed to an elected body had been implemented, setting
the stage for the election of the Universal House of Justice in 1963.
The organic unfoldment of the administration, so carefully nurtured by the Guardian, was
systematically cultivated and further extended under the direction of the House of Justice. The
subsequent span of more than half a century witnessed a host of achievements. Among the most
prominent of these, the Constitution of the Universal House of Justice, hailed by the Guardian as
the “Most Great Law”, was adopted in 1972. Following consultation with the Hands of the Cause,
the functions of that institution were extended into the future through the creation of the
Continental Boards of Counsellors in 1968 and the International Teaching Centre in 1973. In
addition, for the ﬁrst time, Auxiliary Board members were authorized to appoint assistants to
broaden the reach of their ministrations for propagation and protection at the grassroots. The
number of National and Local Assemblies multiplied, and their capabilities developed to serve the
Bahá’í community and extend their inﬂuence through engagement with the wider society.
Regional Bahá’í Councils were introduced in 1997 to help address the growing complexity of the
issues facing National Spiritual Assemblies while maintaining the balance between centralization
and decentralization in a community’s administrative affairs. The system of teaching committees
established in the time of the Guardian gradually gave way to structures that could take
responsibility for planning and decision making at more decentralized levels, penetrating as far as
neighbourhoods and villages. More than three hundred training institutes, over two hundred
Regional Councils, and administrative arrangements in more than ﬁve thousand clusters were
established. At Riḍván 1992 the law of Ḥuqúqu’lláh was applied universally across the Bahá’í
world and its institutional structure subsequently consolidated through the establishment of a
network of Boards of Trustees and Representatives at the regional and national levels, as well as,
in 2005, through the appointment of an International Board of Trustees. Following the passing of
Shoghi Effendi, the construction of Mashriqu’l-Adhkárs in Uganda, Australia, Germany, and
Panama was completed, and others were eventually raised in Samoa, India, and Chile; in 2012, the
process of establishing Houses of Worship was extended to the national and local levels.
Over the century, then, through a series of developmental stages, the relationships among
individuals, communities, and institutions have progressively evolved into ever more complex
forms, and the foundations of the administration have been extended, its methods continually
adapted, and arrangements for collaboration clariﬁed and continually reﬁned. What began at the
start of the ﬁrst century of the Formative Age as a network of elected bodies had become, by the
end of that century, a vast constellation of institutions and agencies stretching from the grassroots
to the international level, uniting the Bahá’í world in thought and action within a common
enterprise across a diversity of cultural contexts and social settings.
Today, although the administration has not yet reached its full maturity, the system
inaugurated by Bahá’u’lláh evinces a new pattern of interactions and a marked dynamism in the
relationships among the three protagonists as they engage in the common purpose of working for
the organic development of the Faith and the betterment of the world. In the company of like-
minded co-workers and in the various settings of study, of reﬂection, and of numerous other social
interactions, individuals express their views and seek out the truth through a process of
consultation, without insisting upon the correctness of their own ideas. Together, they read the
reality of their surroundings, explore the depths of available guidance, draw relevant insights from
the Teachings and from accumulating experience, create cooperative and spiritually uplifting
environments, build capacity, and initiate action that grows in effectiveness and complexity over
time. They attempt to differentiate those areas of activity in which the individual can best
exercise initiative from those which fall to the institutions alone, and with heart and soul they
welcome the guidance and direction of their institutions. Across advanced clusters and within
villages and neighbourhoods that are centres of intense activity, a community emerges with a
sense of common identity, will, and purpose, providing an environment for nurturing the capacity
of individuals and uniting them in a range of complementary and mutually reinforcing activities
that welcome all and seek to uplift everyone. Such communities are increasingly becoming
distinguished by the sense of unity among their members, their freedom from prejudices of all
kinds, their devotional character, their commitment to the equality of women and men, their
selﬂess service to humanity, their educational processes and cultivation of virtue, and their
capacity to systematically learn and contribute to the material, social, and spiritual progress of
society. Those community members called upon to serve on institutions endeavour to be conscious
of their duty to set aside their own likes and dislikes, to never consider themselves to be the
central ornaments of the Cause or superior to others, and to eschew any attempt to exercise
control over the thoughts and actions of the believers. In carrying out their responsibilities, the
institutions facilitate creative and collaborative exchanges among all elements of the community
and strive to build consensus, to overcome challenges, to foster spiritual health and vitality, and to
determine through experience the most efﬁcacious ways to pursue the community’s aims and
purposes. Through various means, including the establishment of educational agencies, they help
foster the spiritual and intellectual development of the believers.
As a result of these new relationships and capacities of the three protagonists, the circle of
those with the ability to think and act strategically has widened, while assistance, resources,
encouragement, and loving guidance are extended wherever needed. Experience and insight are
shared throughout the world, from the grassroots to the international level. The pattern of life
created by this dynamic engagement encompasses millions of souls from all walks of life,
animated by Bahá’u’lláh’s vision of a united world. In country after country, it has drawn the
attention of parents, educators, traditional leaders, ofﬁcials, and leaders of thought to the power of
His system to address the world’s pressing needs. Naturally, not every community exhibits the
characteristics of the most advanced; indeed, in Bahá’í history this has ever been so. Nevertheless,
the appearance of new capacities in any one place signals an evident advance and serves as an
augury that others will surely follow in that path.
In the epochs and centuries ahead, the Administrative Order will continue its organic
evolution in response to the growth of the Faith and the exigencies of a changing society. Shoghi
Effendi anticipated that as “its component parts, its organic institutions, begin to function with
efﬁciency and vigour,” the Administrative Order will “assert its claim and demonstrate its capacity
to be regarded not only as the nucleus but the very pattern of the New World Order destined to
embrace in the fullness of time the whole of mankind”. Thus, as Bahá’u’lláh’s system crystallizes,
it will present humanity with new and more productive ways of organizing its affairs. In the
course of this organic evolution, relationships among individuals, communities, and institutions
will inevitably unfold in new directions and sometimes unexpected ways. Yet, the unfailing divine
protection that encompasses the House of Justice will ensure that, as the Bahá’í world navigates
the turmoil of a most perilous period in humanity’s social evolution, it will follow undeviatingly
the course set by Providence.
The worldwide spread and development of the Faith
From its inception, the community raised by Bahá’u’lláh, though small in numbers and
geographically circumscribed, was galvanized by His lofty teachings and arose to share them
liberally with all those seeking a spiritual path to personal and social transformation. In time, the
friends learned to work closely with like-minded people and organizations to uplift the human
spirit and contribute to the betterment of families, communities, and society as a whole.
Receptivity to Bahá’u’lláh’s message was found in every land, and through devoted and sacriﬁcial
efforts over many generations, Bahá’í communities emerged around the globe, in far-ﬂung cities
and villages, to encompass the diversity of the human race.
During the Dispensation of the Báb, the Faith was established in two countries. In the time of
Bahá’u’lláh it extended to a total of ﬁfteen, and by the close of the ministry of ‘Abdu’l-Bahá it had
reached some thirty-ﬁve countries. During the tumultuous years of world war, ‘Abdu’l-Bahá
revealed one of His priceless legacies, the Tablets of the Divine Plan, His grand design for the
spiritual illumination of the planet through the spread of Bahá’u’lláh’s teachings. This precious
Charter raised a call for collective and methodical endeavour; yet by the time of the Master’s
passing, it had scarcely penetrated the thought and action of the community, and only a few
extraordinary heroes of the Faith, foremost among them Martha Root, had arisen in response.
For twenty years after the Divine Plan was revealed by the pen of ‘Abdu’l-Bahá, its execution
was held in abeyance until such time as the friends, guided by Shoghi Effendi, were able to create
the administrative machinery of the Faith and foster its proper functioning. Only when the initial
administrative structure was ﬁrmly in place could the Guardian begin to articulate a vision of the
unfoldment of the Faith based on ‘Abdu’l-Bahá’s Divine Plan. Just as the administration evolved
through distinct stages of increasing complexity, so too did the effort to share and apply
Bahá’u’lláh’s teachings evolve organically, giving rise to new patterns of community life that
could embrace ever-larger numbers, enable the friends to take on greater challenges, and
contribute to an increased measure of personal and social transformation.
To begin this systematic endeavour, Shoghi Effendi called upon the communities in the United
States and Canada—the chosen recipients of the Tablets of the Divine Plan, whom he had
designated, respectively, as its chief executors and their allies—to devise a “systematic, carefully
conceived, and well-established plan” which was to be “vigorously pursued and continuously
extended”. This call resulted in the launching of the ﬁrst Seven Year Plan in 1937, which carried
the teachings of Bahá’u’lláh to Latin America, followed by the second Seven Year Plan, beginning
in 1946, which emphasized the development of the Faith in Europe. Shoghi Effendi similarly
encouraged the teaching work in other national communities, which subsequently adopted
national plans under his watchful eye. The National Spiritual Assembly of India and Burma
adopted its ﬁrst plan in 1938; the British Isles in 1944; Persia in 1946; Australia and New Zealand
in 1947; Iraq in 1947; Canada, Egypt and Sudan, and Germany and Austria in 1948; and Central
America in 1952. Each of these plans followed the same basic pattern: teaching individuals,
establishing a Local Assembly and raising a community, and opening additional localities on the
home front or in another land—and then repeating the pattern once more. When a sound
foundation was built in a country or territory, a new National Assembly could be raised.
During these years, Shoghi Effendi constantly encouraged the friends to carry out their
responsibility to teach the Faith within the context of the plans adopted by their National
Assemblies. Over time, methods such as pioneering, travelling teaching, ﬁreside gatherings,
summer schools, and participation in the activities of like-minded organizations proved to be
effective in certain places, and he urged the friends in other parts of the world to adopt them.
Expansion efforts were matched by an emphasis on the internal development necessary to
consolidate the identity and character of the Bahá’í Faith as a distinct religious community. This
transformative process was carefully cultivated by the Guardian, who expounded for the believers
the history of their Faith, facilitated the use of the Bahá’í calendar, emphasized regular
participation in Feasts and the commemoration of Holy Days, and patiently guided them to
embrace the obligation of obedience to Bahá’í laws, such as the provisions of Bahá’í marriage.
Gradually, the Faith emerged as a world religion, taking its place among its sister religions.
Along with the inauguration of international institutions, the collective endeavours of the
Faith in the teaching ﬁeld moved into the arena of international cooperation. In 1951, ﬁve national
communities collaborated in the execution of the “highly promising” and “profoundly signiﬁcant”
African Campaign to extend the spread of the Faith across that continent. And in 1953, the Ten
Year Crusade was initiated, uniting the efforts of all twelve existing National Assemblies in one
common global Plan—the ﬁrst of its kind. In this crowning stage of the ministry of the Guardian,
the network of administrative bodies the friends had raised and the proven teaching methods they
had developed were employed in a collective spiritual enterprise the like of which the Bahá’í
community had never before witnessed.
As the believers travelled far and wide to share their precious Faith, they found among divers
peoples a great receptivity to its principles and teachings. These populations discovered within
the Revelation of Bahá’u’lláh a deeper meaning and purpose for their lives, as well as fresh
insights that would enable their communities to overcome challenges and advance spiritually,
socially, and materially. A divine light, initially disseminated gradually from individual to
individual, thus began to be diffused rapidly among the masses of humanity. The harbinger of the
phenomenon of entry by troops foretold by ‘Abdu’l-Bahá became evident in the enrolment of
hundreds of believers in Uganda, The Gambia, the Gilbert and Ellice Islands, and later, in Indonesia
and Cameroon. Before that Plan drew to a close, the process had begun in a number of other
countries, with those individuals embracing the Faith reaching into the tens of thousands or even
more.
After the passing of Shoghi Effendi, the Hands of the Cause ensured the successful
completion of the Ten Year Crusade by following undeviatingly the path he had outlined. By
applying the lessons learned under the guidance of the Guardian, more was accomplished in the
teaching ﬁeld over a single decade than in the previous century. The Faith spread to 131 new
countries and territories, and the number of localities where Bahá’ís resided surpassed eleven
thousand, with a total of ﬁfty-six National Spiritual Assemblies and more than 3,500 Local
Assemblies. The enterprise culminated in the election of the Universal House of Justice by the
members of those National Assemblies, according to the provisions set down by ‘Abdu’l-Bahá.
After its establishment, the House of Justice continued the systematic prosecution of the
Divine Plan, inaugurating its second epoch by gradually broadening and augmenting the range of
activities cultivated by the Guardian, adding to or extending various aspects of the work, and
coordinating and unifying the activities of all the National Assemblies. Among the areas of
emphasis that emerged or received increased attention were the universal participation of
individuals in service to the Cause and the deepening of individuals’ understanding of the laws
and teachings. In addition, the process of strengthening the institutions emphasized collaboration
between the newly constituted Boards of Counsellors and the National Assemblies, as well as
between the Auxiliary Board members and Local Spiritual Assemblies. Community life was
enhanced through a focus on children’s classes, the introduction of activities for youth and women,
and the regular holding of Assembly meetings. Other initiatives included the extensive
proclamation of the Faith and its promotion through the media; the development of centres of
learning, including summer schools and teaching institutes; greater involvement in the life of
society; and the fostering of Bahá’í scholarship.
As a result of all these efforts, by the 1990s the Faith had spread to tens of thousands of
localities and the number of National Assemblies more than tripled to some 180. During this time,
the development of national communities followed two broad patterns which were largely
contingent upon the response of the wider population. In the ﬁrst, local communities tended to be
small in size, and only some grew to number a hundred believers or more. These communities
were often characterized by a strong process of consolidation that allowed for a broad range of
activities and the emergence of a strong sense of Bahá’í identity. Yet, it increasingly became
evident that, though united in shared beliefs, characterized by high ideals, and proﬁcient in
managing its affairs and tending to its needs, such a small community—however much it
prospered or attempted to serve others through its humanitarian efforts—could never hope to
serve as a model for restructuring the whole of society.
The second pattern took shape in those countries where the process of entry by troops began,
resulting in an exponential increase in membership, new localities, and new institutions. In
several countries the Bahá’í community grew to comprise more than one hundred thousand
believers, while India reached some two million. Indeed, in a single two-year period in the late
1980s, more than one million souls embraced the Faith worldwide. Yet, in such places, despite the
creative and sacriﬁcial efforts that were made, the process of consolidation could not keep pace
with expansion. Many became Bahá’ís, but the means did not exist for all these new believers to
become sufﬁciently deepened in the fundamental verities of the Faith and for vibrant communities
to develop. Classes for Bahá’í education could not be established in numbers large enough to serve
an ever-increasing number of children and youth. Over thirty thousand Local Assemblies were
formed, but only a fraction of them began to function. From this experience, it became apparent
that occasional educational courses and informal community activities, though important, were
not sufﬁcient, for they resulted in raising up only a relatively small band of active supporters of
the Cause who, no matter how dedicated, could not provide for the needs of thousands upon
thousands of new believers.
By 1996, the Bahá’í world had reached the point where the many areas of activity that had
previously contributed to so much progress over so many years needed reassessment and
reorientation. Individuals, communities, and institutions needed to learn not only how to initiate a
mode of action that could reach large numbers, but also how to rapidly increase the number of
individuals who could engage in acts of service so that consolidation could keep pace with
accelerating expansion. The effort to introduce the Faith to the many populations of the world had
to become more systematic. The call in the Four Year Plan for a “signiﬁcant advance in the process
of entry by troops” was intended to acknowledge that the circumstances of the Faith, as well as
the conditions of humanity, allowed for, and even required, sustained growth of the Bahá’í world
community on a large scale. Only then could the power of Bahá’u’lláh’s teachings to transform
the character of humankind be increasingly realized.
At the outset of the Four Year Plan, the friends in each region were encouraged to identify the
approaches and methods that applied to their speciﬁc conditions and to set in motion a systematic
process of community development in which they would review their successes and difﬁculties,
adjust and improve their methods accordingly, learn, and move forward without hesitation. When
the course of action was unclear, a range of approaches to the speciﬁc challenges identiﬁed by the
Plan could be tested in different places; when an initiative in a particular area proved, through
experience, to be effective, its features could be shared with institutions at the national or
international level and then be disseminated to other places and even become a component of
future Plans.
Over a quarter century this process of learning about growth gave rise to a range of concepts,
instruments, and approaches which continually enhanced the community’s evolving framework
for action. Among the most prominent of these features was the creation of a network of training
institutes—offering educational programmes for children, junior youth, and youth and adults—for
empowering the friends in large numbers and enabling them to enhance their capabilities for
service. Another was the construct of clusters, which facilitated the systematization of the
teaching work in manageable geographic areas through the initiation and gradual strengthening of
programmes of growth, and accelerated the spread and development of the Faith within each
country and across the world. Within such programmes of growth, a new pattern of community
life emerged, beginning with the multiplication of four core activities that served as portals for the
entry of large numbers, combined with a range of other efforts, including individual and collective
teaching, visiting homes, hosting social gatherings, observing Feast and Holy Days, administering
community affairs, and promoting activities for social and economic development—all of which
together would effect a change in the spiritual character of the community and strengthen social
ties among individuals and families.
In looking back over a century of efforts to execute the provisions of the Divine Plan, it
becomes apparent that the Bahá’í world has experienced a signiﬁcant advance at the level of
culture. Ever greater numbers have become engaged in a process of consciously learning to apply
the Teachings pertaining to growth and development within a framework for action that evolves
through the experience of the friends and the guidance of the House of Justice. The rise in
capacity for engaging in this process of learning is evident in characteristics that are increasingly
manifest in the Bahá’í community: maintaining a humble posture of learning, whether celebrating
successes or persevering in the face of obstacles and setbacks; strengthening Bahá’í identity while
preserving an orientation welcoming to all; and acting in ever-wider spheres of endeavour while
continuing to foster an approach to the work of the Cause that is systematic and coherent. In
thousands of clusters, growing numbers of people have come to view themselves as protagonists
in the acquisition, generation, and application of knowledge for their own development and
progress. They are engaging in discussions as families, friends, and acquaintances on elevated
spiritual themes and matters of social import; initiating activities that shape a pattern of life
distinguished by its devotional character; providing education for young people and increasing
their capacity for service; and contributing to the material and social progress of their
communities. They are empowered to contribute to the betterment of their local community and
to the world as a whole. As they think and act in this way, they have gained a deeper appreciation
of the purpose of religion itself.
Involvement in the life of society
Yet another dimension of the unfoldment of ‘Abdu’l-Bahá’s Divine Plan is a greater
involvement of the Bahá’í community in the life of society. From the inception of his ministry,
Shoghi Effendi drew the attention of the friends again and again to the power of Bahá’u’lláh’s
Revelation to effect an organic change in society—a process which would ultimately result in the
emergence of a spiritual civilization. Bahá’ís, therefore, had to learn to apply Bahá’u’lláh’s
teachings not only for personal spiritual transformation but also for material and social change,
beginning within their own communities and then gradually extending their efforts to embrace
the wider society.
During the time of ‘Abdu’l-Bahá, some Bahá’í communities in Iran, along with a few others in
nearby countries, had reached a size and attained conditions that enabled them to pursue
systematic endeavours for social and economic development. ‘Abdu’l-Bahá worked tirelessly with
the friends to guide and foster their progress. For example, He encouraged the believers in Iran to
establish schools open to girls as well as boys, from all sectors of society, that would offer training
in good character as well as in the arts and sciences. He dispatched believers from the West to
assist with this development work. To the Bahá’í villages of nearby ‘Adasíyyih and far-off
Daidanaw He offered guidance for both the spiritual and material ﬂourishing of these
communities. He directed that dependencies be created for education and other social services
around the Mashriqu’l-Adhkár in ‘Ishqábád. At His encouragement, schools were founded in Egypt
and the Caucasus. After His passing, Shoghi Effendi provided guidance to expand these efforts.
Activities promoting health, literacy, and the education of women and girls spread throughout the
Iranian community. Spurred by the initial impulse that ‘Abdu’l-Bahá had provided, schools
continued to be opened in cities and villages across that country. These schools ﬂourished for a
time, contributing to the modernization of that nation, until 1934 when they were compelled to
close by the government.
Elsewhere, however, Shoghi Effendi advised the friends to concentrate their limited human
and ﬁnancial resources on teaching and on raising the Administrative Order. A letter written on his
behalf explained that “our contributions to the Faith are the surest way of lifting once and for all
time the burden of hunger and misery from mankind, for it is only through the system of
Bahá’u’lláh—Divine in origin—that the world can be gotten on its feet”. Others “cannot contribute
to our work or do it for us”, the letter continued, “so really our ﬁrst obligation is to support our
own teaching work, as this will lead to the healing of the nations”. While individuals found
personal avenues in which they could contribute to material and social development, generally the
Bahá’ís focused their resources on growth and on building their community. In the early years
following the election of the House of Justice, guidance continued for a time in this same vein.
Thus, although the concept of social and economic development is enshrined in Bahá’u’lláh’s
teachings, owing to the circumstances of the Faith throughout the Guardian’s ministry and the
years that followed, it was impracticable for most of the Bahá’í world to undertake development
activities.
In 1983, after decades of unrelenting effort in the teaching ﬁeld and as a consequence of
signiﬁcant growth in many countries across the world, the community of the Greatest Name had
attained the stage at which the work of social and economic development could be—indeed, had to
be—incorporated into its regular pursuits. The friends were urged to strive, through their
application of spiritual principles, rectitude of conduct, and practice of the art of consultation, to
uplift themselves and thus take responsibility as agents of their own development. The Ofﬁce of
Social and Economic Development was established at the World Centre to assist the House of
Justice to promote and coordinate the activities of the friends in this arena throughout the world,
and over time it evolved to facilitate a global process of learning about development. Individual
believers arose to initiate various activities embracing not only Bahá’ís but also the wider
community.
Within a decade, hundreds of development activities had been initiated around the world,
addressing a range of concerns such as the advancement of women, education, health, mass
communication, agriculture, economic activity, and the environment. Activity ranged along a
spectrum of complexity. Fairly simple activities of short duration in villages and towns were
organized in response to speciﬁc problems and challenges faced in those localities. Sustained
projects, such as schools and clinics, were established to meet social needs over an extended period
of time, often along with organizational structures to ensure their viability and effectiveness. And
ﬁnally, by 1996, a few Bahá’í-inspired organizations with relatively complex programmatic
structures were founded by individuals to learn to systematically pursue a coherent approach to
development, within a population, that would result in a signiﬁcant impact in a region. In all these
efforts, the friends sought to apply spiritual principles to practical problems.
As Bahá’í-inspired agencies as well as agencies directly under the authority of Bahá’í
institutions began to appear in one country after another, the impact of their efforts within the
community and the wider society became increasingly evident, manifesting a dynamic coherence
between the material and spiritual dimensions of life. Advances occurred not only in action, but
also at the level of thought. The friends came to understand a set of fundamental concepts: The
world is not divided into categories of developed and underdeveloped—all are in need of
transformation and an environment that provides the spiritual, social, and material conditions
necessary to their security and ﬂourishing. Development is not a process carried out by one people
on behalf of another; rather, people themselves, wherever they reside, are the protagonists of their
own development. Access to knowledge and participation in its generation, application, and
diffusion is at the heart of the endeavour. Efforts start small and grow in complexity as experience
accumulates. Programmes whose effectiveness has been demonstrated in one region can be
systematically introduced into others. As these principles and concepts are applied within a
particular setting, the friends become increasingly adept at analysing their social conditions,
drawing insights from the Writings and from various relevant ﬁelds of knowledge, and initiating
activities that are fully integrated with the work of community building.
By 2018, the extensive spread and increasing complexity of Bahá’í development efforts
around the world had prompted the establishment of a new institution in the Holy Land—the
Bahá’í International Development Organization. This global institution assumed, and further
extends, the functions and mandate previously carried out by the Ofﬁce of Social and Economic
Development, reinforcing the efforts for social action of individuals, communities, institutions, and
agencies everywhere. Like the Ofﬁce that preceded it, its primary purpose is to facilitate the
global process of learning about development that is unfolding in the Bahá’í world, by fostering
and supporting action and reﬂection, the gathering and systematization of experience,
conceptualization, and training—all carried out in the light of the teachings of the Faith.
Ultimately, it seeks to foster a distinctly Bahá’í approach to development.
Parallel with the systematic unfoldment of the processes of expansion and consolidation and
of social and economic development, another major area of action emerged: greater participation in
the prevalent discourses of society. In an increasing number of social settings where deliberations
on human problems occur, Bahá’ís seek to share relevant insights drawn from the ocean of
Bahá’u’lláh’s Revelation. It was Bahá’u’lláh Himself Who initially proclaimed His healing remedy
directly to the world’s leaders and appealed for its adoption by all humanity. Notwithstanding the
failure of the kings and rulers to respond afﬁrmatively to the divine nature of His claim, He called
upon them to apply His principles for the establishment of world peace: “Now that ye have
refused the Most Great Peace, hold ye fast unto this, the Lesser Peace, that haply ye may in some
degree better your own condition and that of your dependents.” ‘Abdu’l-Bahá, in Writings such as
the Tablets to The Hague, and especially in talks delivered during His travels to the West,
unceasingly proclaimed His Father’s teachings to the powerful and the masses grappling with the
myriad difﬁculties facing humanity.
Early in his ministry, Shoghi Effendi, cognizant of the vital importance of making known to
the peoples and leaders of the world the insights and wisdom enshrined in the Bahá’í teachings,
fostered initiatives for this purpose. These included, among others, the opening in 1925 of a Bahá’í
information bureau in Geneva, the publication of the volumes of The Bahá’í World, and the call for
knowledgeable Bahá’ís to correlate the Teachings with contemporary thought in relation to the
manifold pressing problems of the world. After the founding of the United Nations, the Bahá’í
International Community was established in 1948 as a non-governmental organization
representing Bahá’í communities throughout the world and became increasingly engaged in
aspects of the work of that international body. This opened a new chapter in the Faith’s
continuing relationship with governments, global institutions, and agencies of civil society in the
international sphere. While never allowing this area of endeavour to overshadow the primary
importance of the teaching work, the Guardian encouraged the friends to acquaint the wider
society with the implications of Bahá’u’lláh’s teachings. “Collateral to this process of reinforcing
the fabric of the Administrative Order and of widening its basis,” he wrote to one national
community, “a resolute attempt should be made” for the establishment of closer contact with,
among others, “the leaders of public thought”. Stressing association rather than afﬁliation, and
urging the believers to remain untainted by any participation in political affairs, he encouraged
them to engage with kindred organizations concerned with social issues and to acquaint them with
the aims and purposes of the Faith and the nature of its teachings on such matters as the
establishment of world peace.
After the establishment of the Universal House of Justice, this process of participation in the
discourses of society was further extended. At timely moments, the House of Justice itself
arranged for widespread dissemination of the principles of the Faith, as in its message addressed
to the peoples of the world, “The Promise of World Peace”. The Bahá’í International Community
strengthened its position at the United Nations, ultimately securing a more formal association
with various UN agencies in the 1970s. It published statements on world affairs and created a
unique space for engagement with governments as well as non-governmental organizations.
Recognized by those with whom it associated as harbouring no self-interested agenda but working
for the well-being of all peoples, it played a constructive role in various international symposia,
including the Conference on Environment and Sustainable Development in Rio de Janeiro, the
World Conference on Women in Beijing, the World Summit for Social Development in
Copenhagen, and the Millennium Forum in New York. Following the Iranian Revolution and the
renewal of persecution of the Bahá’ís in Iran, several national communities were impelled to enter
into closer dialogue with various national and international institutions and agencies. They
consequently established national ofﬁces of external affairs to reinforce efforts at the international
level to defend the Faith.
As the twenty-ﬁrst century began, the organic progress of the Cause had created conditions
for a more systematic engagement in the discourses of society. International and national Bahá’í
websites dramatically extended the presentation of the Teachings spanning a range of topics. The
Institute for Studies in Global Prosperity was established to conduct research into the implications
of Bahá’u’lláh’s teachings for pressing social issues; in time it also initiated a series of seminars to
promote understanding and develop capacity among Bahá’í university students. The work of the
Bahá’í International Community, initially centred in New York and Geneva, was extended to
regional centres in Addis Ababa, Brussels, and Jakarta. At the national level, ofﬁces of external
affairs increasingly learned how to participate in speciﬁc national discourses in a systematic
manner on behalf of their respective communities. Among the topics addressed intensively across
various nations were the advancement of women, the role of religion in society, the spiritual and
moral empowerment of youth, the promotion of justice, and the strengthening of social cohesion.
Today, a global process of learning from the experience of contributing to these national discourses
is facilitated by the Ofﬁce of Public Discourse at the Bahá’í World Centre. And at the grassroots in
neighbourhoods and villages, and in their professions and other social spaces in which they
participate as individuals, the friends are learning to offer concepts from the Bahá’í Writings as a
contribution to the evolution of thought and action among their compatriots that is necessary to
bring about constructive change.
Involvement at all these levels of society becomes more pressing as the process of the
disintegration of the old world order intensiﬁes and discourse becomes increasingly coarsened and
polarized, leading to the recrudescence of conﬂict among the competing factions and ideologies
that divide humanity. In keeping with their understanding that the transformation envisioned by
Bahá’u’lláh calls for the participation of everyone, Bahá’ís seek to work with the many
sympathetic individuals and organizations who pursue common objectives. In such collaborative
efforts, the friends share insights from the teachings of Bahá’u’lláh as well as practical lessons
gained in their own community-building efforts, while at the same time learning from the
experience of their collaborating partners. In working with individuals, communities, and
organizations both civic and governmental, the friends maintain awareness that the discourse on
many social issues may become contentious or entangled with political ambitions. In all settings
where Bahá’ís become more deeply engaged with the wider society, they seek to foster consensus
and unity of thought, and to promote collaboration and a common search for solutions to
humanity’s pressing problems. To them, the means by which the end is attained is as important
as the end itself.
As the process of becoming ever more involved in the life of the wider society took root in
Bahá’í communities worldwide, it initially unfolded side by side with the teaching work and the
development of the administration. In recent decades, however, the efforts for social action and
involvement in the discourses of society have achieved marked coherence with those related to
expansion and consolidation as the friends have increasingly applied the elements of the
conceptual framework for action of the global Plans. As the friends labour in their clusters, they
are inexorably drawn into the life of the society around them, and the learning process that
propels efforts for growth and community building is extended to an expanding range of activities.
Community life is increasingly characterized by its contribution to material, social, and spiritual
progress as the friends cultivate their capability to understand the conditions of society around
them, create spaces in which to explore concepts from Bahá’u’lláh’s Revelation and from relevant
ﬁelds of human knowledge, bring insights to bear upon practical problems, and build capacity
among the believers and within the wider community. As a result of this burgeoning coherence
across the various areas of endeavour, the most basic grassroots activities for social and economic
development grew from a few hundred in 1990 to several thousand by 2000, and to tens of
thousands by 2021. Bahá’í engagement in social discourse has been met with a resoundingly
afﬁrmative response in countless settings, from neighbourhoods to nations, as a humanity bafﬂed
and divided by the manifold problems resulting from the operation of the forces of disintegration
eagerly seeks new insights. At all levels of society, leaders of thought increasingly associate the
Bahá’í community with fresh conceptions and approaches sorely needed by an ever more
disunited and dysfunctional world. The society-building power of the Faith, mostly latent at the
start of the ﬁrst century of the Formative Age, is now increasingly discernible in country after
country. The release of this society-building power resulting from a new consciousness and a new
capacity for learning among individuals, communities, and institutions worldwide is destined to be
the hallmark of the current and next several stages in the unfoldment of the Divine Plan.
The development of the Bahá’í World Centre
Parallel with the growth of the Faith and the unfoldment of the administration, equally
signiﬁcant developments occurred at the Bahá’í World Centre during the ﬁrst century of the
Formative Age, set in motion by the impulse of another Charter, Bahá’u’lláh’s Tablet of Carmel.
Mention has already been made of the interplay among the processes associated with the three
Charters, including the emergence of institutions and agencies of the administrative centre of the
Bahá’í world. To this account can now be added some reﬂections on the development of its
spiritual centre.
When Bahá’u’lláh’s footsteps touched the shore of ‘Akká, the climactic chapter of His
ministry began. The Lord of Hosts was manifested in the Holy Land. His arrival had been
presaged through the tongues of the Prophets thousands of years before. The fulﬁlment of that
prophecy, however, was not the result of His own volition but was compelled by His persecution
at the hands of His avowed enemies, culminating in His exile. “Upon Our arrival,” He stated in one
Tablet, “We were welcomed with banners of light, whereupon the Voice of the Spirit cried out
saying: ‘Soon will all that dwell on earth be enlisted under these banners.’” The spiritual potency
of that land was immeasurably enhanced by His presence and the interment of His sacred
remains and, soon after, those of His Herald, Himself a Manifestation of God. It is now the point to
which every Bahá’í heart is drawn, the focal centre of their devotions, the goal of every aspiring
pilgrim. The Bahá’í Holy Places welcome the peoples of the Holy Land, and indeed the peoples of
every land. They are a precious trust held for all humanity.
Yet, tenuous was the hold of the Bahá’ís on the spiritual centre of their Faith at the close of
the Heroic Age and for many years thereafter. How difﬁcult it was, at times, for ‘Abdu’l-Bahá even
to offer prayers at His Father’s resting place. How dire was His situation, being falsely charged
with sedition for raising the structure in which, at the command of Bahá’u’lláh, the earthly
remains of the Báb were laid to rest after the long journey from the place of His martyrdom. The
perilous and insecure condition of the World Centre persisted into the ministry of the Guardian, as
evinced when the keys of the Shrine of Bahá’u’lláh were seized by the Covenant-breakers shortly
after he assumed his responsibilities. Thus, among the ﬁrst and most vital duties of Shoghi
Effendi, pursued throughout his ministry, were the protection and preservation, the extension and
beautiﬁcation of the twin Holy Shrines and other Holy Places. To achieve this aim, he had to
navigate a period of tumultuous change in the Holy Land—including global economic disruption,
war, repeated political transition, and social instability—while upholding, like ‘Abdu’l-Bahá before
him, the immutable Bahá’í principles of fellowship with all peoples and respect for established
governmental authority. At one time, he even had to contemplate the transfer of the remains of
Bahá’u’lláh to a suitable setting on Mount Carmel to ensure their protection. And he steadfastly
remained in Haifa during times of tumult and strife, even as he directed the small band of local
believers to disperse to other parts of the world. This taxing yet tirelessly pursued obligation
continued to his ﬁnal days, when the Shrine of Bahá’u’lláh was ﬁnally recognized as a Bahá’í Holy
Place by the civil authorities, and the Bahá’í world was at last free to preserve and beautify its
most sacred site.
In the course of his efforts to acquire, restore, and secure the Holy Places, the Guardian
signiﬁcantly expanded the properties surrounding the Holy Shrine and the Mansion at Bahjí and
initiated what would eventually become extensive formal gardens. On the Mountain of God, he
brought to its long-delayed completion the Shrine of the Báb, begun by ‘Abdu’l-Bahá, adding three
additional rooms, creating its arcade, raising its golden dome, and surrounding it with verdure. He
traced “the far-ﬂung arc around which the ediﬁces of the World Bahá’í Administrative Order” were
to be built; raised at one end of that arc its ﬁrst structure, the International Archives Building; and
situated, at its heart, the resting places of the Greatest Holy Leaf, her brother, and their mother.
The Guardian’s labours for the development of the World Centre were continued under the
direction of the Universal House of Justice. Additional land and Holy Places were acquired and
beautiﬁed, the buildings on the Arc raised, and terraces extended from the bottom to the top of
Mount Carmel, as originally envisioned by ‘Abdu’l-Bahá and begun by the Guardian. Before the
end of the ﬁrst century of the Formative Age, the property in the vicinity of the Shrine of the Báb
was increased to over 170,000 square metres, while a series of land exchanges and acquisitions
extended the property immediately surrounding the Shrine of Bahá’u’lláh from some 4,000 to over
450,000 square metres. And in 2019 construction began in ‘Akká, near the Riḍván Garden, on a
ﬁtting Shrine to serve as the ﬁnal resting place of ‘Abdu’l-Bahá.
Over the course of the century, the pace of the development of the Bahá’í administrative
centre also accelerated. For many years, early in his ministry, the Guardian longed for the
assistance of capable helpers, but the Bahá’í world was then too small to provide the necessary
support. As the community grew, however, the House of Justice was increasingly able to beneﬁt
from a continuous stream of volunteers to establish the departments and agencies vital to a
rapidly developing Faith, serving the needs at the World Centre as well as of the communities
multiplying worldwide. Questions and advice, insights and guidance, visitors and pilgrims now
ﬂow ceaselessly between all parts of the planet and the heart of the Bahá’í world. In 1987, after
decades of change and uncertainty, the patient efforts begun much earlier by Shoghi Effendi to
establish good relations with the civil authorities in Israel culminated in the formal recognition of
the status of the Bahá’í World Centre as the spiritual and administrative centre of the worldwide
Bahá’í community, operating under the aegis of the Universal House of Justice.
Just as the relationships among individuals, communities, and institutions have evolved over
time, building upon previous achievements and rising to meet new challenges, the same can be
said of the Bahá’í World Centre and its relations with the Bahá’ís across the world. The intimate
and inseparable association of the spiritual and administrative centre with the development of the
Bahá’í world was captured in the 24 May 2001 message we addressed to the believers gathered for
the events marking the completion of the projects on Mount Carmel: “The majestic buildings that
now stand along the Arc traced for them by Shoghi Effendi on the slope of the Mountain of God,
together with the magniﬁcent ﬂight of garden terraces that embrace the Shrine of the Báb, are an
outward expression of the immense power animating the Cause we serve. They offer timeless
witness to the fact that the followers of Bahá’u’lláh have successfully laid the foundations of a
worldwide community transcending all differences that divide the human race, and have brought
into existence the principal institutions of a unique and unassailable Administrative Order that
shapes this community’s life. In the transformation that has taken place on Mount Carmel, the
Bahá’í Cause emerges as a visible and compelling reality on the global stage, as the focal centre of
forces that will, in God’s good time, bring about the reconstruction of society, and as a mystic
source of spiritual renewal for all who turn to it.”
Prospect
A few weeks before He passed away, ‘Abdu’l-Bahá was at His home with one of the friends.
“Come with me”, He said, “that we may admire together the beauty of the garden.” Then He
observed: “Behold, what the spirit of devotion is able to achieve! This ﬂourishing place was, a few
years ago, but a heap of stones, and now it is verdant with foliage and ﬂowers. My desire is that
after I am gone the loved ones may all arise to serve the divine Cause and, please God, so it shall
be.” “Ere long”, He promised, will appear those “who shall bring life to the world.”
Dearly loved friends! At the close of the ﬁrst century of the Formative Age, the Bahá’í world
ﬁnds itself endowed with capacity and resources only dimly imagined at the time of ‘Abdu’l-
Bahá’s passing. Generation after generation has laboured, and today a multitude has been raised
up that stretches across the globe—consecrated souls who are collectively building the Faith’s
Administrative Order, widening the reach of its community life, deepening its engagement with
society, and developing its spiritual and administrative centre.
This brief review of the past hundred years has illustrated how the Bahá’í community, in
striving to systematically execute the three Divine Charters, has become a new creation, as
anticipated by ‘Abdu’l-Bahá. Just as the human being passes through various stages of physical
and intellectual growth and development until it reaches maturity, so too the Bahá’í community
develops organically, in size and structure, as well as in understanding and vision, embracing
responsibilities and strengthening relationships among individuals, communities, and institutions.
Over the course of the century, in local settings as well as on a global scale, the series of advances
experienced by the Bahá’í community has enabled it to pursue purposeful action across an ever-
wider range of endeavours.
When the Heroic Age drew to a close, the community faced fundamental questions about how
to organize its administrative affairs in order to respond to the requirements of the Divine Plan.
The Guardian guided the friends in learning how to address those initial questions, a process that
culminated in the nascent international arrangements that were in place at the time of his
passing. The capacity that was built during that period allowed the Bahá’í world to take on a host
of new questions about how it was to carry on the work of the Faith at a greater level of breadth
and complexity under the direction of the Universal House of Justice. Then, yet again, after
making marked progress over several decades, even more questions about still greater
opportunities concerning the future direction of the Cause emerged before the beginning of the
Four Year Plan, which set out a new challenge for a further period of development centred on
achieving a signiﬁcant advance in the process of entry by troops in all parts of the world. It is this
growing capacity to resolve complex questions and then to take on still more complex questions
that characterizes the process of learning that is propelling the progress of the Faith. Thus, it is
evident that with every step forward in its organic unfoldment, the Bahá’í world develops new
powers and new capacities that enable it to take on greater challenges as it strives to achieve
Bahá’u’lláh’s purpose for humanity. And so it shall continue to be, despite the changes and
chances of the world, through crisis and victory, with many an unexpected turn, through countless
stages of the Formative and Golden Ages to the end of the Dispensation.
By the ﬁnal years of the ﬁrst century of the Formative Age, a common framework for action
had emerged that has become central to the work of the community and which informs thought
and gives shape to ever more complex and effective activities. This framework continually evolves
through the accumulation of experience and the guidance of the House of Justice. The pivotal
elements of this framework are the spiritual truths and cardinal principles of the Revelation.
Other elements that also contribute to thought and action involve values, attitudes, concepts, and
methods. Still others include the understanding of the physical and social world through insights
from various branches of knowledge. Within this continually evolving framework, Bahá’ís are
learning how to systematically translate Bahá’u’lláh’s teachings into action to realize His high
aims for the betterment of the world. The signiﬁcance of this increased capacity for learning, and
its implications for the advancement of humanity at the current stage of its social development,
cannot be overestimated.
How much the Bahá’í world has achieved! How much remains to be done! The Nine Year Plan
outlines the tasks that lie immediately ahead. Among the areas of focus are the multiplication and
intensiﬁcation of programmes of growth in clusters worldwide and increased coherence in the
work of community building, social action, and participation in prevalent discourses through the
concerted efforts of the Plan’s three protagonists. The training institute will be further
strengthened and will continue to evolve as an educational organization that develops capabilities
for service. The seeds it sows within the hearts of succeeding cohorts of young people will be
nurtured by other educational opportunities to empower each soul to contribute to social progress
and well-being. The movement of youth will be complemented worldwide by the unprecedented
advancement of women as full partners in community affairs. The capacity of Bahá’í institutions
will be fostered at all levels, with particular attention to the establishment and development of
Local Assemblies and to enhancing their engagement with the wider society and its leaders. The
intellectual life of the community will be cultivated to provide the rigour and clarity of thought
required to vindicate to a sceptical humanity the applicability of the healing remedy of
Bahá’u’lláh’s teachings. And all these efforts will continue through a series of Plans comprising a
challenge, spanning no less than a generation, that will carry the Bahá’í world across the threshold
of its third century.
The determined efforts to gain a fuller understanding of, and to live in accordance with,
Bahá’u’lláh’s teachings take place within the larger context of the twofold process of
disintegration and integration described by Shoghi Effendi. Attaining the objective of the current
series of Plans—the release of ever-increasing measures of the society-building power of the Faith
—calls for an ability to read the reality of society as it responds to, and is shaped by, these twin
processes.
A plethora of destructive forces and events, including environmental degradation, climate
change, pandemics, the decline of religion and morals, the loss of meaning and identity, the
erosion of the concepts of truth and reason, unbridled technology, the exacerbation of prejudices
and ideological contention, pervasive corruption, political and economic upheaval, war and
genocide, have left their traces in blood and anguish on the pages of history and the lives of
billions. At the same time, hopeful constructive trends can also be discerned, which are
contributing to that “universal fermentation” which Shoghi Effendi said is “purging and reshaping
humanity in anticipation of the Day when the wholeness of the human race will have been
recognized and its unity established”. The diffusion of the spirit of world solidarity, a greater
consciousness of global interdependence, the embrace of collaborative action among individuals
and institutions, and a heightened longing for justice and peace are profoundly transforming
human relationships. And thus, the movement of the world towards Bahá’u’lláh’s vision advances
in countless halting steps, in occasional dramatic leaps, and with intermittent stretches where
progress stalls or is even reversed, as humanity forges the relationships that constitute the
foundations of a united and peaceful world.
The destructive forces that buffet the world do not leave the Bahá’í community untouched.
Indeed, the history of every national Bahá’í community bears their mark. As a result, in various
places and at various times, the progress of a particular community was retarded by insidious
social tendencies or temporarily restricted or even extinguished by opposition. Periodic economic
crises reduced the Faith’s already limited ﬁnancial resources, hindering projects for growth and
development. The effects of world war paralysed for a time the ability of most communities to
implement systematic plans. The upheavals that have reshaped the political map of the world
have created obstacles to the full participation of some populations in the work of the Cause.
Religious and cultural prejudices once thought to be receding have re-emerged with fresh
vehemence. Bahá’ís have striven to address such challenges with perseverance and resolve. Yet,
over the past century, no nobler response to the hostile forces unleashed to oppose the advance of
the Cause has been witnessed than that of the Bahá’ís of Iran.
From the earliest years of the Guardian’s ministry, the persecution which the Bahá’ís of Iran
had endured throughout the Heroic Age continued as waves of violent repression swept over that
community, escalating in intensity in the attacks and systematic campaign of oppression which
followed in the wake of the Iranian Revolution and which continues unremittingly to the present
day. Despite all they have endured, the Bahá’ís of Iran have responded with unbowed courage and
constructive resilience. They have won imperishable distinction through such achievements as the
establishment of the Bahá’í Institute for Higher Education to ensure the education of succeeding
generations, their efforts to transform the views of the fair-minded among their compatriots—
whether inside or outside the country—and above all, their endurance of countless injustices,
indignities, and privations in order to protect their fellow believers, maintain the integrity of
Bahá’u’lláh’s Faith in His beloved homeland, and safeguard its presence in that land as a beneﬁt to
its citizens. In such expressions of unswerving fortitude, of consecrated devotion and mutual
support lie essential lessons for how the Bahá’í world must respond to the acceleration of the
destructive forces that can be expected in the years ahead.
At its heart, the challenge presented by the interplay of the processes of integration and
disintegration is the challenge of holding fast to Bahá’u’lláh’s description of reality and to His
teachings, while resisting the pull of controversial and polarizing debates and beguiling
prescriptions that reﬂect futile attempts to deﬁne human identity and social reality through
limited human conceptions, materialist philosophies, and competing passions. “The All-Knowing
Physician hath His ﬁnger on the pulse of mankind. He perceiveth the disease, and prescribeth, in
His unerring wisdom, the remedy”, Bahá’u’lláh states. “We can well perceive how the whole
human race is encompassed with great, with incalculable afﬂictions.” Yet, He adds, “They that are
intoxicated by self-conceit have interposed themselves between it and the infallible Physician.
Witness how they have entangled all men, themselves included, in the mesh of their devices.” If
Bahá’ís become entangled in the delusory notions of contending peoples, if they emulate the
values, attitudes, and practices that deﬁne a self-absorbed and self-serving age, the release of
those forces necessary to redeem humanity from its plight will be delayed and obstructed. Rather,
as the Guardian explains, “The champion builders of Bahá’u’lláh’s rising World Order must scale
nobler heights of heroism as humanity plunges into greater depths of despair, degradation,
dissension, and distress. Let them forge ahead into the future serenely conﬁdent that the hour of
their mightiest exertions and the supreme opportunity for their greatest exploits must coincide
with the apocalyptic upheaval marking the lowest ebb in mankind’s fast-declining fortunes.”
None can anticipate precisely what course the forces of disintegration are destined to take,
what violent convulsions will yet assail humanity in this travailing age, or what obstacles and
opportunities may arise, until the process reaches its culmination in the appearance of that Great
Peace that will signalize the arrival of the stage when, recognizing the unity and wholeness of
humankind, the nations will “put away the weapons of war, and turn to the instruments of
universal reconstruction”. One thing, however, is certain: The process of integration will also
accelerate, knitting together ever more closely the efforts of those who are learning to translate
Bahá’u’lláh’s teachings into reality with those in the wider society who seek justice and peace. In
The Advent of Divine Justice, Shoghi Effendi explained to the Bahá’ís of America that, given the
restricted size of their community and the limited inﬂuence it wielded, they must focus, at that
time, on its own growth and development as it learned to apply the Teachings. He promised,
however, that the time would come when they would be called upon to engage their fellow
citizens in a process of working for the healing and betterment of their nation. That time has now
come. And it has come not only for the Bahá’ís of America, but for the Bahá’ís of the world, as the
society-building power inherent in the Faith is released in ever-greater measures.
Releasing such power has implications for the decades to come. Every people and every
nation has a part to play in the next stage in the fundamental reconstruction of human society.
All have unique insights and experiences to offer for the building of a uniﬁed world. And it is the
responsibility of the friends, as the bearers of Bahá’u’lláh’s restorative message, to assist
populations to release their latent potentialities to achieve their highest aspirations. In this effort,
the friends share this precious message with others, strive to demonstrate the efﬁcacy of the
divine remedy in the lives of individuals and communities, and work together with all those who
appreciate and share the same values and aspirations. As they do so, Bahá’u’lláh’s vision of a
uniﬁed world will offer a hopeful and clear direction to peoples whose perception has been
distorted by the confusion prevailing in the world, and a constructive path for cooperation in the
search for solutions to long-standing social maladies. As the spirit of the Faith increasingly
permeates the hearts to enkindle love and reinforce the shared identity of humanity as one
people, it instils a sense of loyal and conscientious civic responsibility and, in place of the pursuit
of worldly power, redirects energies towards disinterested service in the pursuit of the common
good. Populations increasingly adopt the method of consultation, action, and reﬂection to displace
endless contest and conﬂict. Individuals, communities, and institutions across divers societies
increasingly harmonize their efforts in common purpose to overcome sectarian rivalries, and
spiritual and moral qualities foundational to humanity’s progress and well-being take root in
human character and social practice.
The world is, in truth, moving on towards its destiny. As the Cause of Bahá’u’lláh advances
into the second century of the Formative Age, let all take inspiration from the words of the
This document has been downloaded from the Bahá’í Reference Library. You are free to use its content subject to the terms of use found at www.bahai.org/legalbeloved Guardian, whose guiding hand immutably shaped the century past. Writing in 1938 about
the execution of the ﬁrst stage of the Divine Plan, he said: “The potentialities with which an
almighty Providence has endowed it will no doubt enable its promoters to achieve their purpose.
Much, however, will depend upon the spirit and manner in which that task will be conducted.
Through the clearness and steadiness of their vision, through the unvitiated vitality of their belief,
through the incorruptibility of their character, through the adamantine force of their resolve, the
matchless superiority of their aims and purpose, and the unsurpassed range of their
accomplishments, they who labour for the glory of the Most Great Name … can best demonstrate
to the visionless, faithless, and restless society to which they belong their power to proffer a
haven of refuge to its members in the hour of their realized doom. Then and only then will this
tender sapling, embedded in the fertile soil of a Divinely appointed Administrative Order, and
energized by the dynamic processes of its institutions, yield its richest and destined fruit.”
[signed: The Universal House of Justice]